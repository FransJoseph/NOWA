Konto administratora:

Login:
admin

Hasło:
123456

Życzę udanego urlopu!