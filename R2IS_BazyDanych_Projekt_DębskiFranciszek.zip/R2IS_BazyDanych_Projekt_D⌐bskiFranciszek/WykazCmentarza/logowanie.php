<form method="POST" action="login.php" autocomplete="off">
    <div class="form-group">
        <label for="login">Login</label>
        <input type="text" class="form-control" id="login" name="login" placeholder="Wpisz login" required autofocus>
    </div>
    <div class="form-group">
        <label for="haslo">Hasło</label>
        <input type="password" class="form-control" id="haslo" name="haslo" placeholder="Wpisz hasło" required>
    </div>

    <p>
    <p>

    <button type="submit" class="btn btn-primary">Zaloguj się</button>
</form>