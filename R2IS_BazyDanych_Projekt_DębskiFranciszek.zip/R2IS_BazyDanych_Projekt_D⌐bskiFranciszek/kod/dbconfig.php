<?php
// Konfiguracja połączenia z bazą danych
$server = "localhost";
$user = "root";
$password = "";
$dbname = "cmentarz";
?>